from server import server
server.port = 8521 # Default port
server.launch()
